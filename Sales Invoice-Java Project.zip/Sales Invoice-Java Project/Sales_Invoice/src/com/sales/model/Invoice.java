
package com.sales.model;

import java.util.ArrayList;

public class Invoice
{
    private int number;
    private String date;
    private String cust;
    private ArrayList<Line> lines;
    
    public Invoice()
    {

    }

    public Invoice(int number, String date, String cust)
    {
        this.number = number;
        this.date = date;
        this.cust = cust;
    }

    public double getInvoiceTotal()
    {
        double total = 0.0;
        for (Line line : getLines())
        {
            total += line.getLineTotal();
        }
        return total;
    }
    
    public ArrayList<Line> getLines()
    {
        if (lines == null)
        {
            lines = new ArrayList<>();
        }
        return lines;
    }

    public String getCust()
    {
        return cust;
    }

    public void setCust(String cust)
    {
        this.cust = cust;
    }

    public int getNumber()
    {
        return number;
    }

    public void setNumber(int number)
    {
        this.number = number;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    @Override
    public String toString()
    {
        return "Invoice{" + "Number=" + number + ", Date=" + date + ", Customer=" + cust + '}';
    }
    
    public String getAsCSV()
    {
        return number + "," + date + "," + cust;
    }
    
}
